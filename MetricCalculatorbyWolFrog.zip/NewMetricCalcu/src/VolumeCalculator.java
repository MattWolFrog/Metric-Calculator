import java.util.Scanner;
import java.lang.Math;
public class VolumeCalculator {

	public void VolCal() {
		
		Scanner sc = new Scanner(System.in);
		double opt = 0;
		
		
		
		
		
		do {
		
		//Phase 1 Selections
		System.out.println("-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=");
		System.out.println("You selected the Volume Calculator");
		System.out.println("Select the shape you want to calculate");
		System.out.println("1 - Cone");
		System.out.println("2 - Sphere");
		System.out.println("3 - Cube");
		System.out.println("4 - Cylinder");
		System.out.println("5 - Rectangular Tank");
		System.out.println("6 - Capsule");
		System.out.println("7 - Pyramid");
		System.out.println("8 - TERMINATE");
		opt = sc.nextInt();
		sc.nextLine();
		
		
		
	
		//Phase 2 Options
		
		if (opt ==1) {
			System.out.println("You selected the Cone Volume Calculation");
			System.out.println("...");
			System.out.println("Please enter the Base Radius in meters: ");
			int baserad = sc.nextInt();
			System.out.println("Please enter the Heigth in meters: ");
			int height = sc.nextInt();
			System.out.println("The Volume of the Cone is: "+Math.PI*baserad*baserad*height/3+" meter(s)3\r\n"
					+ "");
			
		} else if (opt ==2) {
			System.out.println("You selected the Sphere Volume Calculation");
			System.out.println("...");
			System.out.println("Please enter the Radius in meters: ");
			int rad = sc.nextInt();
			double pi = Math.PI;
			double volume = (4.0/3.0)*pi*(rad*rad*rad);
			System.out.println("The Volume of the Sphere is: "+volume+" meter(s)3\r\n");
		} else if (opt ==3) {
			System.out.println("You selected the Cube Volume Calculation");
			System.out.println("...");
			System.out.println("Please enter the Side/Edge in meters: ");
			int side = sc.nextInt();
			double cvol = side*side*side;
			System.out.println("The Volume of the Cube is: "+cvol+" meter(s)3\r\n");
		} else if (opt ==4) {
			System.out.println("You selected the Cylinder Volume Calculation");
			System.out.println("...");
			System.out.println("Please enter the Radius in meters: ");
			int rad = sc.nextInt();
			System.out.println("Please enter the Height in meters: ");
			int height = sc.nextInt();
			double cyvol = (rad*rad)*Math.PI*height;
			System.out.println("The volume of the Cylinder is:  "+cyvol+" meter(s)3\r\n");
		} else if (opt ==5) {
			System.out.println("You selected the Rectangular Tank Volume Calculation");
			System.out.println("...");
			System.out.println("Please enter the Length in meters: ");
			int length = sc.nextInt();
			System.out.println("Please enter the Width in meters: ");
			int width = sc.nextInt();
			System.out.println("Please enter the Height in meters: ");
			int height = sc.nextInt();
			double recvol = length*width*height;
			System.out.println("The Volume of the Rectangular Tank is: "+recvol+" meter(s)3\r\n");
		} else if (opt == 6) {
			System.out.println("You selected the Capsule Volume Calculation");
			System.out.println("...");
			System.out.println("Please enter the Base Radius in meters: ");
			int baserad = sc.nextInt();
			System.out.println("Please enter the Height in meters: ");
			int height = sc.nextInt();
			double 	capvol = Math.PI*(baserad*baserad)*((4.0/3.0)*baserad+height);
			System.out.println("The Volume of the Capsule is: "+capvol+" meter(s)3\r\n");
		} else if (opt == 7) {
			System.out.println("You selected the Pyramid Volume Calculation");
			System.out.println("...");
			System.out.println("Please enter the Base Length in meters: ");
			int length = sc.nextInt();
			System.out.println("Please enter the Base Width in meters: ");
			int width = sc.nextInt();
			System.out.println("Please enter the Height in meters: ");
			int height = sc.nextInt();
			double volume = length*width*height/3.0;
			System.out.println("The Area of the Pyramid is: "+volume+" meter(s)3\r\n");
		} else if (opt != 8) {
			System.out.println("<Illegal Option>");
		}
		
	}
		while (opt !=8);
		sc.close();
}}
