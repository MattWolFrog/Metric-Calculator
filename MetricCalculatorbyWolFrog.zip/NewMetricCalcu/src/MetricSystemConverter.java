import java.util.Scanner;
public class MetricSystemConverter {
	public void MSC() {
		
		
		
		   double mmperinch = 25.4;
	       double cmperinch = 2.54;
	       double mperinch = 0.0254;
	       double kmperinch = 2.54E-5;

	       double mmperft = 304.8;
	       double cmperft = 30.48;
	       double mperft = 0.3048;
	       double kmperft = 0.0003048;

	       double mmperm = 1609344;
	       double cmperm = 160934.4;
	       double mperm = 1609.344;
	       double kmperm = 1.609344;
	       
	       
	       
	      

	      Scanner sc = new Scanner(System.in);
	      System.out.println();
	      System.out.println("Please select what you want to convert from: (in, ft, mi)");
	      String convertFrom = sc.next().toLowerCase();
	      System.out.println("Please select what you want to convert to: (mm, cm, m, km)");
	      String convertTo = sc.next().toLowerCase();

	      System.out.println("Please input the Value");
	      double value = sc.nextDouble();

	      sc.close();

	      switch (convertFrom)
	      {
	      case ("in"):
	        {
	            switch (convertTo)
	            {
	                case ("mm"):
	                {
	                    System.out.println("The value of " + value + " inches to mm is: " + (value*mmperinch));
	                    
	                    break;
	                }
	                case ("cm"):
	                {
	                    System.out.println("The value of " + value + " inches to cm is: " + (value*cmperinch));
	                    
	                    break;
	                }
	                case ("m"):
	                {
	                    System.out.println("The value of " + value + " inches to m is: " + (value*mperinch));
	                    
	                    break;
	                }
	                case ("km"):
	                {
	                    System.out.println("The value of " + value + " inches to km is: " + (value*kmperinch));
	                    
	                    break;
	                }
	                default:
	                {
	                    System.out.println("Output units not recognized, must be mm, cm, m, km");
	                    
	                    break;
	                }
	            }
	            break;
	        }
	         case ("ft"):
	         {
	            switch (convertTo)
	            {
	               case ("mm"):
	               {
	                  System.out.println("The value of " + value + "ft to mm is: " + (value*mmperft));
	                  
	                  break;
	               }
	               case ("cm"):
	               {
	                  System.out.println("The value of " + value + "ft to cm is: " + (value*cmperft));
	                  
	                  break;
	               }
	               case ("m"):
	               {
	                  System.out.println("The value of " + value + "ft to m is: " + (value*mperft));
	                  
	                  break;
	               }
	               case ("km"):
	               {
	                  System.out.println("The value of " + value + "ft to km is: " + (value*kmperft));
	                  
	                  break;
	               }
	               default:
	               {
	                  System.out.println("output units not recognized, must be mm, cm, m, km");
	                  
	                  break;
	               }
	            }
	         }
	         case ("mi"):
	         {
	            switch (convertTo)
	            {
	               case ("mm"):
	               {
	                  System.out.println("The value of " + value + "miles to mm is: " + (value*mmperm));
	                  
	                  break;
	               }
	               case ("cm"):
	               {
	                  System.out.println("The value of " + value + "miles to cm is: " + (value*cmperm));
	                  
	                  break;
	               }
	               case ("m"):
	               {
	                  System.out.println("The value of " + value + "miles to m is: " + (value*mperm));
	                  
	                  break;
	               }
	               case ("km"):
	               {
	                  System.out.println("The value of " + value + "miles to km is: " + (value*kmperm));
	                  
	                  break;
	               }
	               default:
	               {
	                  System.out.println("output units not recognized, must be mm, cm, m, km");
	                  
	                  break;
	               }

	            }
	         }
	         default:
	         {
	            System.out.println("input units not recognized, must be in, ft, mi");
	            
	            break;
	         }

	      }
	      }

	   }
	
	


