import java.util.Scanner;
import java.lang.Math;
public class AreaCalculator {
	public void ACal() {
		
		Scanner sc = new Scanner(System.in);
		double option = 0;
		do {
		
		//Phase 1 Selections
		
		
		
		System.out.println("-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=");
		System.out.println("You chose the Area Calculator");
		System.out.println("Please select the shape you want to calculate");
		System.out.println("1 - Rectangle");
		System.out.println("2 - Triangle");
		System.out.println("3 - Trapezoid");
		System.out.println("4 - Circle");
		System.out.println("5 - Parallelogram");
		System.out.println("6 - Ellipse");
		System.out.println("7- TERMINATE");
		option = sc.nextInt();
		sc.nextLine();
		
		
		//Phase 2 Options
		
		
		if (option == 1) {
			System.out.println("You selected the Rectangle Area Calculation");
			System.out.println("...");
			System.out.println("Please enter the Length in meters: ");
			double length = sc.nextInt();
			System.out.println("Please enterh the Width in meters: ");
			double width = sc.nextInt();
			System.out.println("The Area of the Triangle is: "+length*width+" meter(s)");
			
		} else if (option == 2) {
			System.out.println("You selected the Triangle Area Calculation");
			System.out.println("...");
			System.out.println("Please enter the Height in meters: ");
			double height = sc.nextInt();
			System.out.println("Please enter the Base in meters: ");
			double base = sc.nextInt();
			System.out.println("The Area of the Triangle is: "+base*height/2+" meter(s)");
			
		} else if (option == 3) {
			System.out.println("You selected the Trapezoid Area Calculation");
			System.out.println("...");
			System.out.println("Please enter the Base 1 in meters: ");
			double a = sc.nextInt();
			System.out.println("Please enter the Base 2 in meters: ");
			double b = sc.nextInt();
			System.out.println("Please enter the Height in meters: ");
			double height = sc.nextInt();
			System.out.println("The Area of the Trapezoid is: "+a+b*height+" meter(s)");
		
		} else if (option ==4) {
			System.out.println("You selected the Circle Area Calculation");
			System.out.println("...");
			System.out.println("Please enter the Radius in meters: ");
			double rad = sc.nextInt();
			System.out.println("The Area of the Circle is: "+Math.PI*rad*rad+" meter(s)");
			
		} else if (option ==5) {
			System.out.println("You selected the Parallelogram Area Calculation");
			System.out.println("...");
			System.out.println("Please enter the Base in meters: ");
			double basep = sc.nextInt();
			System.out.println("Please enter the Height in meters: ");
			double heightp = sc.nextInt();
			System.out.println("The Area of the Parallelogram is: "+basep*heightp+" meter(s)");
			
		} else if (option ==6) {
			System.out.println("You selected the Ellipse Area Calculation");
			System.out.println("...");
			System.out.println("Please enter the Semi-Major Axes in meters: ");
			double smjr = sc.nextInt();
			System.out.println("Please enter the Semi-Minor Axes in meters: ");
			double smnr = sc.nextInt();
			System.out.println("The Area of the Ellipse is: "+Math.PI*smjr*smnr+" meter(s)");
			
		} else if (option !=7) {
			System.out.println("<Illegal Option>");
			
			
		}
		
		
		
		
	}
		while (option !=7);
		sc.close();
		
	}

}
