import java.util.Scanner;
import java.lang.Math;

public class main {

	public static void main(String[] args) {
		
		
		
		Scanner sc = new Scanner(System.in);
		String options="";
	
	
		//INTRO
		System.out.println("Welcome to the Metric System and Area - Volume Calculator v1.0 Beta by Matthew Dela Torre & co.");
		System.out.println("=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=");
		System.out.println("...");
		String username, password;
        Scanner s = new Scanner(System.in);
        System.out.print("Enter username:");
        username = s.nextLine().toLowerCase();
        System.out.print("Enter password:");
        password = s.nextLine().toLowerCase();
        if(username.equals("user") && password.equals("user"))
        {
            System.out.println("Authentication Successful");
            
        
		
		
		
		
		//Phase 1 Selection
		
		System.out.println("A - Area Calculator");
		System.out.println("B - Volume Calculator");
		System.out.println("C - Surface Area");
		System.out.println("D - Metric System Converter");
		options = sc.nextLine().toUpperCase();
		
		
		
		
		
		if (options.equals("A")) {
		AreaCalculator AreaCal = new AreaCalculator();
		AreaCal.ACal();

	} else if (options.equals("B")) {
		VolumeCalculator VolumeCal = new VolumeCalculator();
		VolumeCal.VolCal();
	}else if (options.equals("C")) {
		SurfaceAreaCalculator SurfaceCal = new SurfaceAreaCalculator();
		SurfaceCal.SACal();
	}else if (options.equals("D")) {
		MetricSystemConverter MSC = new MetricSystemConverter();
		MSC.MSC();
	}
        }
        else
        {
            System.out.println("Authentication Failed");
}}
		
}
		
