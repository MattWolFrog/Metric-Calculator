import java.util.Scanner;
import java.lang.Math;
public class SurfaceAreaCalculator {
	public void SACal() {
		
		Scanner sc = new Scanner(System.in);
		double opt = 0;
		
		
		
		
		do {
		
		
		//Phase 1 Selections
		System.out.println("-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=");
		System.out.println("You selected the Surface Area Calculator");
		System.out.println("Select the shape you want to calculate");
		System.out.println("1 - Ball");
		System.out.println("2 - Cone");
		System.out.println("3 - Cube");
		System.out.println("4 - Cylindrical Tank");
		System.out.println("5 - Rectangular Tank");
		System.out.println("6 - Conical Frustum");
		System.out.println("7 - Pyramid");
		System.out.println("8 - TERMINATE");
		opt = sc.nextInt();
		sc.nextLine();
		
		
		
		//Phase 2 Options
		if (opt ==1) {
			System.out.println("You selected the Ball Surface Area Calculation");
			System.out.println("...");
			System.out.println("Please enter the Radius in meters: ");
			int rad = sc.nextInt();
			double ballsf = 4*Math.PI*(rad*rad);
			System.out.println("The Surface Area of the Ball is: "+ballsf+" meter(s)2\r\n");
		}else if (opt ==2) {
			System.out.println("You selected the Cone Surface Area Calculation");
			System.out.println("...");
			System.out.println("Please enter the Radius in meters: ");
			int r = sc.nextInt();
			System.out.println("Please enter the Height in meters: ");
			int h = sc.nextInt();
			double length, surfacearea;
			length = Math.sqrt(r*r+h*h);
			surfacearea = Math.PI*r*length+Math.PI*(r*r);
			System.out.println("The Surface Area of the Cone is: "+surfacearea+" meter(s)2\r\n");
		}else if (opt ==3) {
			System.out.println("You selected the Cube Surface Area Calculation");
			System.out.println("...");
			System.out.println("Please enter the Edge in meters: ");
			int edge = sc.nextInt();
			double surfacearea = 6*(edge*edge);
			System.out.println("The Surface Area of the Cube is: "+surfacearea+" meter(s)2\r\n" );
		}else if (opt ==4) {
			System.out.println("You selected the Cylindrical Tank Surface Area Calculation");
			System.out.println("...");
			System.out.println("Please enter the Radius in meters: ");
			int rad = sc.nextInt();
			System.out.println("Please enter the Height in meters: ");
			int height = sc.nextInt();
			double surfacearea = 2*Math.PI*rad*height+2*Math.PI*(rad*rad);
			System.out.println("The Surface Area of the Cylindrical Tank is:"+surfacearea+" meter(s)2\r\n" );
		}else if (opt ==5) {
			System.out.println("You selected the Rectangular Tank Surface Area Calculation");
			System.out.println("...");
			System.out.println("Please enter the Length in meters: ");
			int l = sc.nextInt();
			System.out.println("Please enter the Height in meters: ");
			int h = sc.nextInt();
			System.out.println("Please enter the Width in meters: ");
			int w = sc.nextInt();
			double surfacearea = 2*l*w+2*l*h+2*w*h;
			System.out.println("The Surface Area of the Rectangular Tank is: "+surfacearea+" meter(s)2\r\n");
		} else if (opt ==6) {
			System.out.println("You selected the Conical Frustum Surface Area Calculation");
			System.out.println("...");
			System.out.println("Please enter the Top Radius in meters: ");
			int tr = sc.nextInt();
			System.out.println("Please enter the Bottom Radius in meters: ");
			int br = sc.nextInt();
			System.out.println("Please enter the Height in meters: ");
			int h = sc.nextInt();
			double s = Math.sqrt((br-tr)*(br-tr)+(h*h));
			double topsa = Math.PI*(tr*tr);
			double botsa = Math.PI*(br*br);
			double lateralsurfacearea = Math.PI*(br+tr)*s;
			double totalsurfacearea = topsa+botsa+lateralsurfacearea;
			System.out.println("The Lateral Surface Area of the Conical Fustrum is: "+lateralsurfacearea+" meter(s)2\r\n");
			System.out.println("The Total Surface Area of the Conical Fustrum is: "+totalsurfacearea+" meter(s)2\r\n");
		}else if (opt ==7) {
			System.out.println("You selected the Pyramid Surface Area Calculation");
			System.out.println("...");
			System.out.println("Please enter the Base Length in meters: ");
			int l = sc.nextInt();
			System.out.println("Please enter the Base Width in meters: ");
			int w = sc.nextInt();
			System.out.println("Please enter the Pyramid Height in meters: ");
			int h = sc.nextInt();
			double surfacearea = l*w+l*	Math.sqrt((w/2.0)*(w/2.0)+(h*h))+w*Math.sqrt((l/2.0)*(l/2.0)+(h*h));
			System.out.println("The Surface Area of the Pyramid is: "+surfacearea+" meter(s)2\r\n");
		}else if (opt !=8) {
			System.out.println("<Illegal Option>");
		}
		
		
		
		
		
	}
		while (opt !=8);
		sc.close();

}}
